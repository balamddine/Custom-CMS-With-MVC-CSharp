﻿using Data.Common;
using Data.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Models
{
    public class PageModel
    {

        [DisplayName("is Hidden")]
        public bool isHidden { get; set; }
        public List<PageModel> ChildNodes { get; set; }
        public List<PageContentKeyVal> Contents { get; set; }
        [DisplayName("Friendly url")]
        public string FriendlyUrl { get; set; }
        public int ParentId { get; set; }
        public string Link { get; set; }
        public bool isDeleted { get; set; }
        public PageTemplateModel mPageTemplate { get; set; }
        [DisplayName("Display Order")]
        [Required]
        public int MenuOrder { get; set; }
        [DisplayName("Template")]
        [Required]
        public int PageTemplateID { get; set; }
        public int PageContentID { get; set; }
        [DisplayName("Name")]
        [Required]
        public string Name { get; set; }
        public int Id { get; set; }
        public string menuHTML { get; set; }

        public static PageModel GetFromPage(Page item)
        {
            PageModel b = new PageModel
            {
                Id = item.Id,
                Name = item.Name,
                ParentId = item.ParentId,
                isDeleted = item.isDeleted,
                isHidden = item.isHidden,
                MenuOrder = item.MenuOrder,
                ChildNodes = new List<PageModel>(),
                PageContentID = item.PageContentID,
                PageTemplateID = item.PageTemplateID,
                FriendlyUrl = item.FriendlyUrl,
                menuHTML = "",
                Link = Sitesettings.WebsiteUrl + item.Link,
                Contents = GetContents(item.Id)
            };

            return b;
        }
        public static List<PageContentKeyVal> GetContents(int pageid)
        {
            var T = new PageContentHelper().GetAllFieldsByPageID(pageid);
            List<PageContentKeyVal> mycontents = new List<PageContentKeyVal>();
            foreach (var item in T)
            {
                if (item.ContentFieldTypeID == 1 || item.ContentFieldTypeID == 2)//html
                {
                    mycontents.Add(new PageContentKeyVal
                    {
                        key = item.ContentFieldName,
                        val = item.HtmlContent                        
                    });
                }
            }
            return mycontents;
        }

    }
}
