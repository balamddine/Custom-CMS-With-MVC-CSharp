﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Models
{
    public class PageContentKeyVal
    {
        public string key { get; set; }
        public string val { get; set; }
        public int langid { get; set; }
    }    
}
