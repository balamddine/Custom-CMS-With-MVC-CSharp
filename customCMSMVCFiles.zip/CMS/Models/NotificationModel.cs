﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CMS.Models
{
    public class NotificationModel
    {
        public int TotalCount { get; set; }
        public int ContactCount { get; set; }
        public int NewsltterCount { get; set; }
        public int VacancyCount { get; set; }
       
    }
}